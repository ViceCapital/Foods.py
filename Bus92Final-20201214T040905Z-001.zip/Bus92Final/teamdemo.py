# -*- coding: utf-8 -*-
"""
Created on Mon Nov 23 15:46:42 2020

@author: cynth
"""

import pandas
foodsdf = pandas.read_csv("foods.csv")
entrees = foodsdf.Entrees
entrees = list(entrees)
for e in entrees:
    print(e)
adf = foodsdf.sort_values("Entrees", ascending=True)
ddf = foodsdf.sort_values("Sides", ascending=False)
adf.to_csv("teama.csv")
ddf.to_csv("teamd.csv")